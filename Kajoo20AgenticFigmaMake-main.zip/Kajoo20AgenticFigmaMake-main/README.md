
  # Kajoo 2.O Latest v.916 (Clean Code)

  This is a code bundle for Kajoo 2.O Latest v.916 (Clean Code). The original project is available at https://www.figma.com/design/YqWw0mViyDKNis25EAraTr/Kajoo-2.O-Latest-v.916--Clean-Code-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  