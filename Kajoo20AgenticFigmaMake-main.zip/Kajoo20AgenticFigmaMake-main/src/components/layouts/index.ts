// Re-export from new module location for backward compatibility
export { ViewLayout } from '../modules/layout';