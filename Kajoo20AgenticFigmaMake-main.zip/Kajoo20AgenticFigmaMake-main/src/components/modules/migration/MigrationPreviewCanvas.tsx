// Temporary re-export until full migration
export { MigrationPreviewCanvas } from '@/components/MigrationPreviewCanvas';
