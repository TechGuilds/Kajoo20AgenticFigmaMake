// Temporary re-export until full migration
export { SourceSitemapPanel } from '@/components/SourceSitemapPanel';
