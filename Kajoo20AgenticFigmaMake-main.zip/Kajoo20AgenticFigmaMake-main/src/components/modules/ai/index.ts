// AI Module - AI-related components
export { AIInbox } from './AIInbox';
export type { InboxItem, InboxItemStatus, InboxItemType } from './AIInbox';
