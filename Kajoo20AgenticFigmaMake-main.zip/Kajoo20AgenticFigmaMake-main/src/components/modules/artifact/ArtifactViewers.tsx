// Temporary re-export until full migration
export { SitecoreArtifactView, CodeArtifactView } from '@/components/ArtifactViewers';
