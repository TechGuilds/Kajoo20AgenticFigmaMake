// Temporary re-export until full migration
export { IntegrationManager } from '@/components/IntegrationManager';
