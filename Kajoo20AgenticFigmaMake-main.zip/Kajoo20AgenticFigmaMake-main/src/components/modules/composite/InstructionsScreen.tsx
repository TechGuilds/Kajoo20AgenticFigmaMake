// Temporary re-export until full migration
export { InstructionsScreen } from '@/components/InstructionsScreen';
