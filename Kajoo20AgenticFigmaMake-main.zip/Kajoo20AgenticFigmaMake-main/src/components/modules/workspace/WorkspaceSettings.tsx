// Temporary re-export until full migration
export { WorkspaceSettings } from '@/components/WorkspaceSettings';
